package com.example.practice2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView tx2;
    ImageView img2;
    ArrayList<detail> detailList = new ArrayList<detail>();
    ArrayList<String> detailTitle = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tx2=findViewById(R.id.description);
        img2=findViewById(R.id.imageView);
        fillingData();
        tx2.setText(detailList.get(0).getDetails());

        int imgId = getResources().getIdentifier(detailList.get(0).getImages(),"drawable",getPackageName());
        img2.setImageResource(imgId);



    }
    public void fillingData(){
        detailList.add(new detail("The house has 3 bedroom,2 washroom and in 150 square feet.","downloada"));
        detailList.add(new detail("The house has 4 bedroom,2 washroom and in 200 square feet.","downloadb"));
        detailList.add(new detail("The house has 5 bedroom,3 washroom and in 180 square feet.","downloadc"));
        for(int i=0;i<detailList.size();i++){
            detailTitle.add(detailList.get(i).getDetails());
        }



    }
}