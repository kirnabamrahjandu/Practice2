package com.example.practice2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class page2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    TextView tx1;
    Spinner sp1;
    ImageView img1;
    Button btn;
    ArrayList<House>HouseList = new ArrayList<House>();
    ArrayList<String> houseTitle = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        fillData();
        tx1=findViewById(R.id.price);
        sp1= findViewById(R.id.sp);
        img1=findViewById(R.id.img);
        btn=findViewById(R.id.button);


        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,houseTitle);
        sp1.setAdapter(aa);
        tx1.setText(HouseList.get(0).getPrice());
        sp1.setOnItemSelectedListener(this);
        btn.setOnClickListener(this);



    }
    public void fillData(){
        HouseList.add(new House("grand villa","downloada",250000));
        HouseList.add(new House("grand ","downloadb",350000));
        HouseList.add(new House("rose villa","downloadc",250500));
        for(int i=0;i<HouseList.size();i++){
            houseTitle.add(HouseList.get(i).getName());
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        tx1.setText(HouseList.get(i).getPrice());
        int imgId = getResources().getIdentifier(HouseList.get(i).getImage(),"drawable",getPackageName());
        img1.setImageResource(imgId);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);


    }
}