package com.example.practice2;

public class detail {
    private String details;
    public String images;

    public detail(String details, String images) {
        this.details = details;
        this.images = images;
    }

    public String getDetails() {
        return details;
    }

    public String getImages() {
        return images;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setImages(String images) {
        this.images = images;
    }
}
